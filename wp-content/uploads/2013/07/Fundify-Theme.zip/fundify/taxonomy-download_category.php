<?php 
/**
 * Campaign Category Archives.
 *
 * Same as normal archive view.
 */

locate_template( array( 'archives-campaigns.php' ), true );