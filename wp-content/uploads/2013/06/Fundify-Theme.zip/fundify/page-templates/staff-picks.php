<?php
/**
 * Template Name: Staff Picks
 *
 * This should be used in conjunction with the Fundify plugin.
 *
 * @package Fundify
 * @since Fundify 1.3
 */

locate_template( array( 'page-templates/new-this-week.php' ), true );